<table width="110" border="0">
  <tr>
    <td width="104"><p align="justify">&nbsp;</p>
      <p align="justify"><strong><img src="images/icon/Home.png" width="40" height="40" align="left" /></strong><a href="home.php">Home <br />Page</a></p>
      <p align="justify"><strong><img src="images/icon/Info.png" width="40" height="40" align="left" />Data Akademik </strong></p>
      <ul>
        <li><a href="siswa.php" align="center">Data Siswa</a></li>
        <li><a href="mapel.php" align="center">Data Mapel</a></li>
        <li><a href="guru.php" align="center">Data Guru</a></li>
      </ul>
      <p><strong><img src="images/icon/Tools.png" width="40" height="40" align="left" />Transaksi Akademik </strong></p>
      <ul>
        <li><a href="mapel_siswa.php">Ambil Mapel</a></li>
        <li><a href="input_nilai.php">Penilaian</a></li>
      </ul>
      <p align="justify"><strong><img src="images/icon/Action-paste-icon.png" width="40" height="40" align="left" /></strong><a href="raport.php">Raport <br />
      Siswa</a></p>
      <hr />
      <p align="center"><img src="images/icon/Calender.png" width="48" height="48" /><br />
      <? include "kalender.php"; ?></p>
      <hr />      <p align="center"><a href="logout.php">Logout</a></p>
    </td>
  </tr>
</table>
