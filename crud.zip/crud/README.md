# Phpdanmysql.com
Tutorial membuat CRUD dalam satu halaman Php dan MYSQL -
tutorial membuat CRUD di php - CRUD (Create, Read, Update, Delete) adalah sebuah halaman yang dapat untuk membuat, menampilkan, mengupdate dan juga menghapus tanpa berpindah ke halaman lain. kelebihan dari crud sendiri merupakan dapat memperkecil file di dalam server kita (tanpa banyak file).
Untuk tutorial lengkapnya bisa baca disini <a href="https://phpdanmysql.com/cara-membuat-crud-satu-halaman-php-mysql/" real="follow">tutorial membuat CRUD di php - CRUD (Create, Read, Update, Delete)</a>


## About
Phpdanmysql.com adalah situs belajar web programming, dalam situs ini anda bisa mengedit kode, menjalankan kode, dan mendownload kode. 
dengan memakai interaktif editor tentunya akan membuat kita lebih cepat memahami script.

#Tutorial Terkait

<a href="https://phpdanmysql.com/tutorial-lengkap-belajar-html-dasar-hingga-mahir/" real="follow">Tutorial Lengkap Belajar HTML dari Dasar Hingga Mahir</a><br>

<a href="https://phpdanmysql.com/tutorial-belajar-css-dasar-untuk-pemula/" real="follow">Tutorial Belajar CSS Dasar untuk Pemula</a><br>

<a href="https://phpdanmysql.com/lengkap-tutorial-belajar-mysql-pemula/" real="follow">Tutorial Lengkap Belajar Php dan MySQL untuk Pemula</a><br>
